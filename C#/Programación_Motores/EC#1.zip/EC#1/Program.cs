﻿using System;
            /******************************/
            /**                          **/
            /**        MOTORES DE        **/
            /**        VIDEOJUEGOS       **/
            /**                          **/
            /**          EXAMEN          **/
            /**           2026           **/
            /**                          **/
            /******************************/

    ////////////////////////////////////////////////
    ///                                          ///
    ///               VALENCIA                   ///
    ///              06/11/2026                  ///
    ///                                          ///
    ///   AUTOR: Patryk Buczynski Jedrzejewski      ///
    ///                                          ///
    ////////////////////////////////////////////////


namespace examenMotores
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio1();
            //Ejercicio2();
            Ejercicio4();

        }

        /**********
         *   1    *
         **********/

        static void Ejercicio1()
        {
            bool opcion = false;
            int opcionEscogida;

            Console.WriteLine("[ CENTRO DE ENTRENAMIENTO ]");
            Console.WriteLine("");

            do
            {
                Console.WriteLine("1. Calcular experiencia ganada");
                Console.WriteLine("2. Calcular daño crítico");
                Console.WriteLine("3. Salir");
                opcionEscogida = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("");

                if(opcionEscogida == 1 || opcionEscogida == 2 || opcionEscogida == 3)
                {
                    opcion = true;
                }
                
            } while (opcion == false);

            if(opcionEscogida == 1)
            {                
                Console.WriteLine("1. Calcular experiencia ganada");
                Console.WriteLine("");

                Console.Write("¿Nivel inicial? ");
                int nivelInicial = int.Parse(Console.ReadLine() ?? "0");

                Console.Write("¿Nivel final? ");
                int nivelFinal = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("");

                int experienciaGanada = 100 *(nivelFinal-nivelInicial);
                Console.WriteLine("Has ganado " + experienciaGanada + " de experiencia.");
            }
            else if(opcionEscogida == 2)
            {
                int criticoAleatorio = GenerarNumeroAleatorio(2,3);

                Console.WriteLine("2. Calcular daño crítico");
                Console.WriteLine("");

                Console.Write("Daño base: ");
                int dañoBase = int.Parse(Console.ReadLine() ?? "0");

                int dañoCritico = dañoBase * criticoAleatorio;
         
                if(criticoAleatorio == 2)
                {
                    Console.Write("Daño crítico: " + dañoCritico + "( ¡Doble!)");
                }
                else
                {
                    Console.Write("Daño crítico: " + dañoCritico + "( ¡Triple!)");
                }
            }
            else
            {
                Console.Write("Adios.");
            }
        }

        /**********
         *   2    *
         **********/

        static void Ejercicio2()
        {
            Console.Write("Número de jugadores: ");
            int jugadores = int.Parse(Console.ReadLine() ?? "0");
            Console.WriteLine();

            int jugadorElegido = 1;
            int mayorPuntuacion = 0;
            int menorPuntuacion = 999999; //Se inicializa con un número alto para entrar dentro del rango
            int puntuacionTotal = 0;
            int mediaPuntuacion = 0;

            for (int i = 1; i <= jugadores; i++)
            {
                bool opcion;
                int puntuacion;

                Console.Write("Jugador " + jugadorElegido + ": ");
                puntuacion = int.Parse(Console.ReadLine() ?? "0");
                    
                if(puntuacion <= 0)
                {
                    opcion = false;
                }
                else
                {
                    opcion = true;
                }

                while(opcion == false)
                {
                    Console.Write("Error vuelve a introducir puntuación: ");
                    puntuacion = int.Parse(Console.ReadLine() ?? "0");

                    if(puntuacion > 0)
                    {
                        opcion = true;
                    }
                }

                // Calculos adicionales
                if(puntuacion > mayorPuntuacion)
                {
                    mayorPuntuacion = puntuacion;
                }
                if(puntuacion < menorPuntuacion)
                {
                    menorPuntuacion = puntuacion;
                }

                puntuacionTotal = puntuacion + puntuacionTotal;
                mediaPuntuacion = puntuacionTotal / jugadores;

                jugadorElegido++;
            }

            Console.WriteLine();
            Console.WriteLine("Mayor puntuación: " + mayorPuntuacion);
            Console.WriteLine("Mayor puntuación: " + menorPuntuacion);
            Console.WriteLine("Mayor puntuación: " + mediaPuntuacion);
        }

        /**********
         *   4    *
         **********/

        static void Ejercicio4()
        {
            bool opcion = true;
            int experienciaTotal;
            int nivel = 1;
            int nivelAlcanzado = 0;
            int experienciaSiguienteNivel = nivel * 100;
            int experienciaSobrante = 0;
            int puntosRestante = 0;

            Console.Write("Experiencia total: ");
            experienciaTotal = int.Parse(Console.ReadLine() ?? "0");

            if(experienciaTotal <= 0)
            {
                opcion = false;
            }

            while (opcion == false)
            {
                Console.Write("Error vuelve a intentar: ");
                experienciaTotal = int.Parse(Console.ReadLine() ?? "0");

                if (experienciaTotal > 0)
                {
                    opcion = true;
                }
            }
            
            // Calculos
            while(experienciaTotal > 0)
            {
                experienciaTotal = experienciaTotal - experienciaSiguienteNivel;

                nivelAlcanzado++;
                nivel++;
                experienciaSobrante = experienciaTotal - experienciaSiguienteNivel;
            }
            while(nivel <= 0)
            {
                experienciaSiguienteNivel = nivel * experienciaSiguienteNivel;
                nivel--;
            }
            
            experienciaSobrante = experienciaSobrante * (-1); // Se usa para dar un numero positivo
            
            Console.WriteLine("Calculando...");
            Console.WriteLine("Nivel alcanzado: " + nivelAlcanzado);
            Console.WriteLine("Experiencia sobrante: " + experienciaSobrante);
            Console.WriteLine("Faltan " + puntosRestante + " puntos para el nivel "+ (nivelAlcanzado + 1));
        }

        /************
         * NO TOCAR *
         ************/
        public static int GenerarNumeroAleatorio(int minimo, int maximo)
        {
            //DECLARAMOS LA SEMILLA ALEATORIA
            Random semilla = new Random();

            int numeroAleatorio;

            // RECOGER EL VALOR ALEATORIO
            numeroAleatorio = semilla.Next(minimo, maximo);

            // GG
            return numeroAleatorio;
        }

    }
}
